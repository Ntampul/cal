# Simple investment calculator for inidividuals to calculate simple and compound interest including bond repayments.
Simple investment calculator 
